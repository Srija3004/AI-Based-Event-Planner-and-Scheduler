//package com.example.eventplanner.controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//import com.example.eventplanner.model.Planner;
//import com.example.eventplanner.service.PlannerService;
//import java.util.List;
//
//@RestController
//@RequestMapping("/api/planners")
//@CrossOrigin(origins = "*") // Allow your frontend to call this API
//public class PlannerController {
//
//    @Autowired
//    private PlannerService plannerService;
//
//    // Get all planners
//    @GetMapping
//    public ResponseEntity<List<Planner>> getAllPlanners() {
//        return ResponseEntity.ok(plannerService.getAllPlanners());
//    }
//
//    // Get planner by user ID
//    @GetMapping("/{userId}")
//    public ResponseEntity<Planner> getPlannerByUserId(@PathVariable Long userId) {
//        return ResponseEntity.ok(plannerService.getPlannerByUserId(userId));
//    }
//}
package com.example.eventplanner.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/planner")
public class PlannerController {

    @PostMapping("/events")
    public Map<String, Object> createEvent(@RequestBody Map<String, Object> eventData) {
        System.out.println("Received event: " + eventData);

        // Simulate saving to DB (you can replace with repository.save(event))
        Map<String, Object> response = new HashMap<>();
        response.put("status", "success");
        response.put("message", "Event saved successfully!");
        response.put("data", eventData);
        return response;
    }
}

