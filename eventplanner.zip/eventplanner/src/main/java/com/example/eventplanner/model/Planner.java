package com.example.eventplanner.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "planners")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Planner {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Link to user account
    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;

    @Column(nullable=false)
    private String name;

    @Column(nullable=false)
    private String email;

    private String phone;

    private Integer experienceYears;

    private String specialties;
}
