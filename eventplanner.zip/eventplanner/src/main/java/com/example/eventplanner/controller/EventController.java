package com.example.eventplanner.controller;

import com.example.eventplanner.model.Event;
import com.example.eventplanner.model.User;
import com.example.eventplanner.repository.EventRepository;
import com.example.eventplanner.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/events")
@CrossOrigin(origins = {
        "http://localhost:63342",  // IntelliJ preview
        "http://127.0.0.1:63342",  // backup for IntelliJ
        "http://localhost:5500",   // optional VSCode live server
        "http://127.0.0.1:5500"
})
 // your frontend port
public class EventController {

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private UserRepository userRepository;

    // ✅ Save Event (linked to user)
    @PostMapping("/create")
    public Map<String, Object> createEvent(@RequestBody Map<String, Object> payload) {
        System.out.println("Received payload: " + payload); // 🧩 debug log

        Object userIdObj = payload.get("userId");
        if (userIdObj == null) {
            throw new RuntimeException("❌ userId missing in request body! Received: " + payload);
        }

        Long userId = Long.valueOf(userIdObj.toString());
        User user = userRepository.findById(userId).orElse(null);
        if (user == null) {
            throw new RuntimeException("User not found for ID: " + userId);
        }

        Event e = new Event();
        e.setName((String) payload.get("name"));
        e.setDescription((String) payload.get("description"));
        e.setCity((String) payload.get("city"));
        e.setVenue((String) payload.get("venue"));
        e.setDate((String) payload.get("date"));
        e.setTime((String) payload.get("time"));
        e.setGuestCount((payload.get("guestCount") != null) ? ((Number) payload.get("guestCount")).intValue() : null);
        e.setDuration((payload.get("duration") != null) ? ((Number) payload.get("duration")).intValue() : null);
        e.setBudget((payload.get("budget") != null) ? ((Number) payload.get("budget")).doubleValue() : null);
        e.setTheme((String) payload.get("theme"));
        e.setRequirements((String) payload.get("requirements"));
        e.setUser(user);

        Event saved = eventRepository.save(e);

        Map<String, String> recs = new HashMap<>();
        recs.put("venue", "Suggested venue: " + (e.getCity() != null ? e.getCity() + " Grand Hall" : "Best Venue"));
        recs.put("catering", "Recommended catering for " + (e.getGuestCount() != null ? e.getGuestCount() : "your") + " guests");
        recs.put("timeline", "Plan start at " + e.getTime() + " for " + (e.getDuration() != null ? e.getDuration() + " hours" : "your event duration"));

        Map<String, Object> result = new HashMap<>();
        result.put("event", saved);
        result.put("recommendations", recs);

        return result;
    }
}
