package com.example.eventplanner.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "event")
public class Event {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;          // event name
    private String description;   // optional
    private String city;          // event city
    private String venue;         // optional
    private String date;          // date as string (2025-12-20)
    private String time;          // time as string (18:00)
    private Integer guestCount;   // optional
    private Integer duration;     // optional
    private Double budget;        // optional
    private String theme;         // optional
    private String requirements;  // special requirements

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;  // link to user who created event
}
